package com.example.ecom_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
