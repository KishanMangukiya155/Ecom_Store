import 'package:flutter/material.dart';

class AppTheme {
  static Color blue = const Color(0xff4700A0);
  static Color yellow = Colors.amber;
}
