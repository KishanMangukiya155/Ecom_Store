import 'package:flutter/material.dart';

class Product extends StatefulWidget {
  const Product({super.key});

  @override
  State<Product> createState() => _ProductState();
}

class _ProductState extends State<Product> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Container(
          height: 115,
          width: 365,
          decoration: BoxDecoration(
              color: Color(0xff4700A0),
              borderRadius:
                  BorderRadius.only(bottomRight: Radius.circular(40))),
          child: Padding(
            padding: const EdgeInsets.only(top: 30, left: 15, right: 15),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "All Product",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  CircleAvatar(
                    minRadius: 18,
                    backgroundColor: Colors.white,
                    child: Container(
                        height: 32,
                        width: 32,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            image: DecorationImage(
                                image: AssetImage("assets/image/profie.png"),
                                fit: BoxFit.cover))),
                  )
                ]),
          ),
        ),
        Container(
          height: 685,
          //color: Colors.red,
          child: ListView.builder(
            padding: EdgeInsets.zero,
            itemBuilder: (BuildContext context, int index) {
              return Container(
                width: 350,
                height: 96,
                // color: Colors.black12,
                margin: EdgeInsets.symmetric(vertical: 6, horizontal: 15),
                child: Row(children: [
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(
                        color: Color(0xff4700A0),
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Product Name",
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w700),
                      ),
                      SizedBox(height: 3),
                      Text(
                        "Product Name",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  Padding(
                    padding:
                        const EdgeInsets.only(right: 10, bottom: 0, top: 0),
                    child: Column(
                        //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: Icon(Icons.delete, color: Color(0xff4700A0)),
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: Icon(Icons.delete, color: Color(0xff4700A0)),
                          ),
                        ]),
                  ),
                ]),
              );
            },
          ),
        )
      ]),
    );
  }
}
